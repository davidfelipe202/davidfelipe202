# TODO List
- Add the ability to load extension sources
- Dialog polyfill may not be loaded on all pages where it is required. Breaks app on firefox.

- Library updates page is missing
- Recently read page is missing
- Latest updates page is missing
- Source chooser is incomplete

