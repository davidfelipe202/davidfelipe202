package kotlinx.coroutines.experimental.android

import kotlinx.coroutines.GlobalScope

val UI = GlobalScope.coroutineContext