/**
 * All of the files in this package were copied unchanged from the Android Open Source Project (AOSP)
 */
package android.support.annotation;