package android.support.v7.preference;

public class PreferenceScreen {
}
