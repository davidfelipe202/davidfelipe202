/**
 * Package copied and modified from: https://android.googlesource.com/platform/libcore/+/master/json
 */
package org.json;