package com.github.pwittchen.reactivenetwork.library

import android.net.NetworkInfo

class Connectivity {
    val state = NetworkInfo.State.CONNECTED
}
