package com.f2prateek;
//TODO Consider if we can change this package into an Android dependency