package xyz.nulldev.ts.config

import com.typesafe.config.Config

/**
 * Abstract config module.
 */
abstract class ConfigModule(config: Config)
