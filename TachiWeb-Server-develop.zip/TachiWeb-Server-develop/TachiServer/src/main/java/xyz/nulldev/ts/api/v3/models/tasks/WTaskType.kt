package xyz.nulldev.ts.api.v3.models.tasks

enum class WTaskType {
    RESTORE_BACKUP,
    UPDATE_LIBRARY
}