package xyz.nulldev.ts.api.v2.java.model

enum class SortDirection {
    ASCENDING,
    DESCENDING
}