package xyz.nulldev.ts.api.v3.models.manga

enum class WMangaViewer {
    DEFAULT,
    LEFT_TO_RIGHT,
    RIGHT_TO_LEFT,
    VERTICAL,
    WEBTOON
}
