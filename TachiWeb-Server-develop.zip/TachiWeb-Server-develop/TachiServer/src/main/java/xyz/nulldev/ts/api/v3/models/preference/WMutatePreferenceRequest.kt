package xyz.nulldev.ts.api.v3.models.preference

data class WMutatePreferenceRequest(
        val value: Any?
)