package xyz.nulldev.ts.api.java.model.categories

interface Category {
    /**
     * The name of the category
     */
    var name: String
}
