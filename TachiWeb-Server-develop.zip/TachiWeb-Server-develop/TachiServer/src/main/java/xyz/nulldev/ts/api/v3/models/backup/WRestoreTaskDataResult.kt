package xyz.nulldev.ts.api.v3.models.backup

enum class WRestoreTaskDataResult {
    SUCCESSFUL,
    SUCCESSFUL_WITH_ERRORS,
    FAILED
}