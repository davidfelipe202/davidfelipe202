package xyz.nulldev.ts.api.v3.models.categories

interface WMutateCategoryRequestBase {
    val name: String?
    val order: Int?
}