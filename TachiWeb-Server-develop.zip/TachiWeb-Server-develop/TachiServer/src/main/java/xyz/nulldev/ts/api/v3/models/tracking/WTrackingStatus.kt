package xyz.nulldev.ts.api.v3.models.tracking

data class WTrackingStatus(
        val displayName: String,
        val id: Int
)