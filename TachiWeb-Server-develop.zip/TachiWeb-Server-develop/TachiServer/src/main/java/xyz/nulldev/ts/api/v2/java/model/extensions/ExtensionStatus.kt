package xyz.nulldev.ts.api.v2.java.model.extensions

enum class ExtensionStatus {
    AVAILABLE, UNTRUSTED, INSTALLED
}