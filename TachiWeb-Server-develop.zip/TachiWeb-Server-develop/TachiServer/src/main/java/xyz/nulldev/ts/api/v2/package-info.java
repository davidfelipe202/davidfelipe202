/**
 * @deprecated Use v3 API
 */
package xyz.nulldev.ts.api.v2;