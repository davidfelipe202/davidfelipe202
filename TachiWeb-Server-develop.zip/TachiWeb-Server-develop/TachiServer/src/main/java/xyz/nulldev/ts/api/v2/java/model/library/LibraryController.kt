package xyz.nulldev.ts.api.v2.java.model.library

interface LibraryController {
    /**
     * Library sort, filter and display state
     */
    var flags: LibraryFlags
}