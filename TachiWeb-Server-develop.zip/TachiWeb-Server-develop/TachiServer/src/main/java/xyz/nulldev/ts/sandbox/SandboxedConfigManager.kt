package xyz.nulldev.ts.sandbox

import xyz.nulldev.ts.config.ConfigManager

class SandboxedConfigManager(override val configFolder: String): ConfigManager()