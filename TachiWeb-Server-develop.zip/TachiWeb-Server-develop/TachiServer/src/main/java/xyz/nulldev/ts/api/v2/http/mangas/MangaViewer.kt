package xyz.nulldev.ts.api.v2.http.mangas

import xyz.nulldev.ts.api.v2.java.model.mangas.Viewer

data class MangaViewer(val id: Long,
                       val viewer: Viewer?)