package xyz.nulldev.ts.api.v2.java.model.chapters

data class ReadingStatus(val lastPageRead: Int?,
                         val read: Boolean?)
