package xyz.nulldev.ts.api.v2.java.model.mangas

interface MangaLikeModel {
    val id: Any

    val viewer: Any?
}