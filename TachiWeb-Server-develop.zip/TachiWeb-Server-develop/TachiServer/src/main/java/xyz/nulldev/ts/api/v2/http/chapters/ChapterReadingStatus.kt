package xyz.nulldev.ts.api.v2.http.chapters

import xyz.nulldev.ts.api.v2.java.model.chapters.ReadingStatus

data class ChapterReadingStatus(val id: Long,
                                val readingStatus: ReadingStatus?)