package xyz.nulldev.ts.api.v2.java.model

enum class FilterStatus {
    ANY,
    INCLUDE,
    EXCLUDE
}