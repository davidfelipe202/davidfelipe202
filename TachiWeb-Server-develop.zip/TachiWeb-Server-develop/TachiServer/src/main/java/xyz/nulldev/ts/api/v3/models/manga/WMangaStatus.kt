package xyz.nulldev.ts.api.v3.models.manga

enum class WMangaStatus {
    UNKNOWN,
    ONGOING,
    COMPLETED,
    LICENSED
}