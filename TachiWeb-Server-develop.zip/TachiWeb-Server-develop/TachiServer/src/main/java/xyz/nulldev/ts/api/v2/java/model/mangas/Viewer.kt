package xyz.nulldev.ts.api.v2.java.model.mangas

enum class Viewer {
    DEFAULT,
    LEFT_TO_RIGHT,
    RIGHT_TO_LEFT,
    VERTICAL,
    WEBTOON
}