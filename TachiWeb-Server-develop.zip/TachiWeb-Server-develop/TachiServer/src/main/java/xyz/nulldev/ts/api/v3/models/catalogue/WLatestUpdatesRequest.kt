package xyz.nulldev.ts.api.v3.models.catalogue

data class WLatestUpdatesRequest(
        val page: Int
)