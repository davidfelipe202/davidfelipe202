package xyz.nulldev.ts.api.v3.models.extensions

enum class WExtensionStatus {
    INSTALLED,
    UNTRUSTED,
    AVAILABLE
}