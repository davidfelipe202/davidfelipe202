package xyz.nulldev.ts.api.v3.models.preference

data class WPreference(
        val key: String,
        val value: Any?
)