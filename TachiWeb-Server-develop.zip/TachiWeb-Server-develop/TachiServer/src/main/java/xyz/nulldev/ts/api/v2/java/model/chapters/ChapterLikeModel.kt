package xyz.nulldev.ts.api.v2.java.model.chapters

interface ChapterLikeModel {
    val id: Any

    val readingStatus: Any?
}