package xyz.nulldev.ts.api.v3.models.downloads

enum class WDownloadStatus {
    QUEUED,
    DOWNLOADING,
    DOWNLOADED,
    ERROR
}