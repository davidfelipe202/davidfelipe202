package xyz.nulldev.ts.api.v3.models.urls

enum class WUrlHandleResultType {
    TRACKING_LOGIN
}