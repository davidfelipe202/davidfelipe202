package xyz.nulldev.ts.api.v3.models.urls

data class WUrlHandleResult(
        val data: String?,
        val type: WUrlHandleResultType
)