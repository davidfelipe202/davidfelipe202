package xyz.nulldev.ts.api.v3.models.tracking

enum class WTrackingOAuthLoginStatus {
    SUCCESSFUL,
    FAILED_UNKNOWN,
    FAILED_ALREADY_LOGGED_IN
}