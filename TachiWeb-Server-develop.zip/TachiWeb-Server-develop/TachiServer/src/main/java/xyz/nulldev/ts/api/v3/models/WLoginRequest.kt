package xyz.nulldev.ts.api.v3.models

data class WLoginRequest(
        val username: String,
        val password: String
)